package com.system.realm;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.cas.CasRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;

import com.system.bean.sys.SysPermission;
import com.system.bean.sys.SysRole;
import com.system.bean.sys.SysUser;
import com.system.service.sys.SysUserService;
import com.system.util.common.PubUtil;

/**
 * 
 * @title UserRealm.java
 * @author liyuanguo
 * @time 2018年8月2日 下午5:14:27
 * @description 用户授权信息域
 * @version V1.0
 */
public class UserRealm extends CasRealm {
	
	@Autowired
    private SysUserService sysUserService;


	protected final Map<String, SimpleAuthorizationInfo> roles = new ConcurrentHashMap<String, SimpleAuthorizationInfo>();
	
	/**
	 * 设置角色和权限信息
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {

		//String account = (String) principals.getPrimaryPrincipal();
		String username = (String) getAvailablePrincipal(principalCollection);

        
        List<SysRole> list_r=null;
        List<SysPermission> list_permission=null;
        try {
            SysUser	 sysUser = sysUserService.selectRoleByName(username);
            list_r=sysUser.getRoles();
            SysUser sysUser_p=sysUserService.selectPermissionByUser(username);
            list_permission=sysUser_p.getPermissions();
            		
        } catch (Exception e) {
            e.printStackTrace();
        }
        //通过用户名从数据库获取权限/角色信息
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        Set<String> r = new HashSet<String>();
        if (list_r.size()>0&&list_r!=null) {
        	for (SysRole sysRole: list_r) {
				r.add(sysRole.getfFullname());
			}
//          r.add(role.getRolename());
            info.setRoles(r);
        }
        //查询所有角色的所有权限
        //写入用户权限info.setStringPermissions();
        Set<String> perms = new HashSet<String>();
        if (list_permission.size()>0&&list_permission!=null) {
			for (SysPermission sysPermission : list_permission) {
				perms.add(sysPermission.getfEncode());
			}
		}
        //t.add("student:query");
        info.setStringPermissions(perms);
        return info;
	}
	
	
	/**
	 * 1、CAS认证 ,验证用户身份
	 * 2、将用户基本信息设置到会话中
	 */
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) {

		AuthenticationInfo authc = super.doGetAuthenticationInfo(token);

		String account = (String) authc.getPrincipals().getPrimaryPrincipal();
		if(null==PubUtil.getUser()){
			SysUser sysUser = sysUserService.findByName(account);
			SecurityUtils.getSubject().getSession().setAttribute("sysUser", sysUser);
			System.out.println(sysUser.getfAccount());
		}
		return authc;
	}
	

}

package com.system.dao.sourceManage.log;

import com.system.bean.log.SysLog;
import com.system.util.generate.MyMapper;

public interface SysLogMapper extends MyMapper<SysLog> {
}
/**
 * 
 */
package com.system.controller.base;

import java.beans.PropertyEditor;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.PropertyEditorRegistry;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.system.util.common.HttpServletRequestUtil;
import com.system.util.result.ResultUtil;


/**
 * @title AdminController.java
 * @author liyuanguo
 * @time 2018年7月16日 下午2:53:01
 * @description TODO
 * @version V1.0
 */
@Controller
public class AdminController {
	
	/**
	  * 
	  * @author liyuanguo
	  * @time 2018年7月16日 下午3:02:02
	  * @description 管理员页面显示
	  */
	@RequestMapping("/admin/showAdmin")
	public String showAdmin() throws Exception {
		HttpServletRequest request = HttpServletRequestUtil.getReq();
		request.setAttribute("key", "测试:无参");//关键数据
        return "admin/showAdmin";
	}
	@UserLogAnnotation(module="amin测试",methods="测试页面跳转")
    @RequestMapping("/admin/testlog")
    public void testlog() throws Exception {
		HttpServletRequest request = HttpServletRequestUtil.getReq();
		request.setAttribute("key", "测试:无参");//关键数据
    }
    /**
     * 
     * @author liyuanguo
     * @time 2018年7月16日 下午3:02:09
     * @description 学生页面
     */
    
	@RequestMapping("/student/showStudent")
    public String showStudent() throws BindException {
		Subject subject = SecurityUtils.getSubject();
        return "student/showStudent";

    }
	
	
	 /**
	  * 
	  * @author liyuanguo
	  * @time 2018年7月16日 下午3:02:19
	  * @description 教师页面显示
	  */
    @RequestMapping("/teacher/showTeacher")
    public String showTeacher() throws Exception {
        return "teacher/showTeacher";
    }
    
}

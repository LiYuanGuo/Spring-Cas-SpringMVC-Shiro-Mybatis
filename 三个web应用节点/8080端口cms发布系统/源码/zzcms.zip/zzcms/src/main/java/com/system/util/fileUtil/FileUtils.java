/**
 * 
 */
package com.system.util.fileUtil;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

import org.apache.poi.POIXMLDocument;
import org.apache.poi.POIXMLTextExtractor;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.web.multipart.MultipartFile;

/**
 * @title FileUtils.java
 * @author liyuanguo
 * @time 2018年8月1日 下午5:11:52
 * @description TODO
 * @version V1.0
 */

public class FileUtils {

	/**
	 * 
	 * @author liyuanguo
	 * @time 2018年8月1日 下午5:13:51
	 * @description
	 * @param fileName
	 *            文件路径
	 */
	public static String readfile(String filePath) {
		File file = new File(filePath);
		InputStream input = null;
		try {
			input = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		StringBuffer buffer = new StringBuffer();
		byte[] bytes = new byte[1024];
		try {
			for (int n; (n = input.read(bytes)) != -1;) {
				buffer.append(new String(bytes, 0, n, "utf-8"));
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (null != input) {
				try {
					input.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		// System.out.println(buffer);
		return buffer.toString();
	}

	/**
	 * 
	 * @author liyuanguo
	 * @time 2018年8月1日 下午5:14:14
	 * @description TODO
	 * @param fileName
	 *            文件路径
	 * @param html
	 *            内容
	 */
	public static void writeFile(String fileName, String html) {
		File f = new File(fileName);
		BufferedWriter writer = null;
		try {
			if (!f.exists()) {
				f.createNewFile();
			}
			OutputStreamWriter write = new OutputStreamWriter(new FileOutputStream(f), "utf-8");
			writer = new BufferedWriter(write);
			writer.write(html);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (null != writer) {
				try {
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * 解析2007文档版本
	 * @time 2018年8月1日 下午5:18:14
	 * @param mulFile
	 * @return
	 */
	public static String readWord_2007(MultipartFile mulFile) {
		String text = "";
		try {
			OPCPackage oPCPackage = POIXMLDocument.openPackage(mulFile.getName());
			XWPFDocument xwpf = new XWPFDocument(oPCPackage);
			POIXMLTextExtractor ex = new XWPFWordExtractor(xwpf);
			text = ex.getText();
			// 去掉word文档中的多个换行
			System.out.println("读取Word文档成功！");
			return text;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}

	/**
	 * 解析2003文档版本
	 * 
	 * @param mulFile
	 * @return
	 * @name 
	 */
	public static String readWord_2003(MultipartFile mulFile) {
		String text = "";
		try {
			InputStream stream = mulFile.getInputStream();
			HWPFDocument document = new HWPFDocument(stream);
			WordExtractor word = new WordExtractor(document);
			text = word.getText();
			// 去掉word文档中的多个换行
			System.out.println("读取Word文档成功！");
			stream.close();
			return text;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}

	// 删除临时文件
	@SuppressWarnings("unused")
	public static void deleteFile(File... files) {
		for (File file : files) {
			if (file.exists()) {
				file.delete();
			}
		}
	}

}

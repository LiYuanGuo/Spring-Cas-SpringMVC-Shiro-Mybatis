/**
 * 
 */
package com.system.util.regexUtil;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @title RegexUtil.java
 * @author liyuanguo
 * @time 2018年7月31日 下午4:17:23
 * @description TODO
 * @version V1.0
 */

public class RegexUtil {
	
	//匹配标签中属性
	public static final String paramRegex=" .*=[\\w\"]*";
	
	//匹配多个空格
	public static final String blackRegex="\\s{2,}";
	
	/**
	 * hzw
	 * 读取文件内容
	 * @param path - 模版地址
	 * @return
	 */
	@SuppressWarnings("resource")
	public static String readFile(String path) {
		File file = new File(path);
		FileInputStream input;
		try {
			input = new FileInputStream(file);
			Long fileLength= file.length();
			byte[] d = new byte[fileLength.intValue()];
			input.read(d);
			input.close();
			return new String(d, "UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * hzw
	 * 获取指定标签头 - 只查找 第一个 对应标签 
	 * @param element	- 标签名 
	 * @param periphery	- 对应正文
	 * @return 
	 */
	public static String getLabelTop(String element,String periphery){
		// 获取指定标签头
		String lableStr = "<" + element + ".*?>";
		Matcher lableMatcher = Pattern.compile(lableStr).matcher(periphery);
		if(lableMatcher.find()){
			String lable = lableMatcher.group();
			return lable;
		}
		return null;
	}
	
	/**
	 * 
	 * @author liyuanguo
	 * @time 2018年7月31日 下午4:28:39
	 * @description 获取匹配器
	 * @param content 匹配的内容
	 * @param regex 正则表达式
	 */
	public static Matcher getMatcherByRegex(String content,String regex){
		Pattern pattern = Pattern.compile(regex);
		return pattern.matcher (content);
	}
	
	/**
	 * 
	 * @author liyuanguo
	 * @time 2018年7月31日 下午4:54:56
	 * @description 获取标签头的属性
	 * @param doc 传入标签起始部分内容 如<DTS_DOCUMENTS NUM=\"60\"  b=45>
	 */
	public static Map<String,Object> getParamMap(String doc){
		Matcher matcher=getMatcherByRegex(doc,paramRegex);
		HashMap<String, Object> result=new HashMap<>();
		while (matcher.find ()){
			String temp=matcher.group().trim();
			temp=temp.replaceAll(blackRegex, " ");
			for(String paramStr:temp.split(" ")){
				String[] entry=paramStr.split("=");
				result.put(entry[0].trim().toUpperCase(), entry[1].replace("\"", "").trim());
			}
		}
		return result;
	}
	
	public static void main(String[] args) {
		Map<String,Object> map=getParamMap("<DTS_DOCUMENTS NUM=\"60\"  b=45>");
		System.out.println(map.get("NUM"));
	}

}

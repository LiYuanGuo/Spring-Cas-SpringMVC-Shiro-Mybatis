package com.system.util.encryption;

import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

/**
 * UniCode  转码
 */
public class UniCodeUtil {
	
	
	/**
	 * 字符串转换unicode
	 * @param string
	 * @return
	 */
    public static String stringToUnicode(String string) {
        StringBuffer unicode = new StringBuffer();
        for (int i = 0; i < string.length(); i++) {
            char c = string.charAt(i);  // 取出每一个字符
            unicode.append("u" +Integer.toHexString(c));// 转换为unicode
        }
        return unicode.toString();
    }

    /**
     * unicode 转字符串
     * @param unicode
     * @return
     */
    public static String unicodeToString(String unicode) {
        StringBuffer string = new StringBuffer();
        String[] hex = unicode.split("u");
        for (int i = 1; i < hex.length; i++) {
            int data = Integer.parseInt(hex[i], 16);// 转换出每一个代码点
            string.append((char) data);// 追加成string
        }
        return string.toString();
    }
    
    /**
     * map转码
    * @Title: mapToUnicode 
    * @Description: TODO 
    * @param map
    * @return String
     */
    public static String mapToUnicode(Map<String, Object> map) {
    	String json = JSONObject.toJSONString(map);
        StringBuffer unicode = new StringBuffer();
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);  // 取出每一个字符
            unicode.append("u" +Integer.toHexString(c));// 转换为unicode
        }
        return unicode.toString();
    }

    /**
     * 解码返回map
    * @Title: unicodeToMap 
    * @Description: TODO 
    * @param unicode
    * @return Map<String,Object>
     */
    public static Map<String, Object> unicodeToMap(String unicode) {
        StringBuffer string = new StringBuffer();
        String[] hex = unicode.split("u");
        for (int i = 1; i < hex.length; i++) {
            int data = Integer.parseInt(hex[i], 16);// 转换出每一个代码点
            string.append((char) data);// 追加成string
        }
        return JSON.parseObject(string.toString());
    }
    
}
